
import http from "http";
import fs from "fs";
import path from "path";

const server = http.createServer((req, res) => {
    let filePath = "";

    if (req.url === "/home") {
        filePath = "pages/home.html";
    }
    else if (req.url === "/about") {
        filePath = "pages/about.html";
    }
    else if (req.url === "/contact") {
        filePath = "pages/contact.html";
    }
    else if (req.url === "/style.css") {
        filePath = "public/style.css";
    }
    else {
        filePath = "pages/404.html";
        res.statusCode = 404;
    }

    const fullPath = path.join(process.cwd(), filePath);

    const contentType = filePath.endsWith(".css")
        ? "text/css"
        : "text/html";

    fs.readFile(fullPath, (err, data) => {
        if (err) {
            res.writeHead(500, { "Content-Type": "text/plain" });
            res.end("Internal Server Error");
            return;
        }

        if (!res.headersSent) {
            res.writeHead(200, { "Content-Type": contentType });
        } else {
            res.setHeader("Content-Type", contentType);
        }

        res.end(data);
    });
});

server.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
