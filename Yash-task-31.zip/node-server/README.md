Node.js Architecture

About

This is a basic web server project built using Node.js. It uses the built-in HTTP module to handle different routes and serve HTML pages. Users can visit Home, About, and Contact pages through different URLs.

Technologies Used

Node.js
JavaScript
HTTP Module
HTML
CSS
File System Module

Features

Creates a web server using the Node.js HTTP module
Handles multiple routes
Serves Home, About, and Contact HTML pages
Provides CSS styling to all pages
Uses asynchronous file reading
Handles invalid routes with a custom 404 page
Uses appropriate HTTP status codes
Runs on port 3000

How to Run

Open the project folder in VS Code
Open the terminal
Run npm install (if required)
Run node server.js
Open http://localhost:3000/home in your browser

Available Routes

Home: http://localhost:3000/home
About: http://localhost:3000/about
Contact: http://localhost:3000/contact
404: Any invalid route

Author

Yash